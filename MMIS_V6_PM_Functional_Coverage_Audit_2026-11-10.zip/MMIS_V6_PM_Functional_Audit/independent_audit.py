from playwright.sync_api import sync_playwright
from pathlib import Path
import json, re, os
ROOT=Path(__file__).resolve().parent / 'input_demo'
report={'audit':'Independent PM functional coverage audit','date':'2026-11-10','test_type':'offline browser+source consistency','observations':[],'pageErrors':[]}
def record(key,expected,actual,pass_,severity='informational'):
 report['observations'].append({'id':key,'expected':expected,'actual':actual,'pass':pass_,'severity':severity})
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path=os.environ.get('MMIS_CHROMIUM_PATH') or None,args=['--no-sandbox','--disable-dev-shm-usage'])
 pg=b.new_page(viewport={'width':1440,'height':960},accept_downloads=True)
 pg.set_default_timeout(5000)
 pg.on('pageerror',lambda err:report['pageErrors'].append(str(err)))
 pg.set_content((ROOT/'index.html').read_text(), wait_until='domcontentloaded')
 # V6 supplied response claims broad QA; independently check view roster
 roster=pg.evaluate('''()=>({pages: Object.keys(window.MMIS_V6.state.page==='global'?{global:1,requests:1,markets:1,vendors:1,facilities:1,suppliers:1,finance:1,staff:1,roles:1,imports:1,gate:1,rental:1,'shop-finder':1,'my-business':1,library:1,design:1,review:1}:{}), open:window.MMIS_V6.getReport().openCases})''')
 record('page-inventory','17 advertised destinations',len(roster['pages']),len(roster['pages'])==17)
 record('request-open-count','55 unique open synthetic cases',roster['open'],roster['open']==55)
 # focus on advertised global exact drilldown
 pg.evaluate('()=>window.MMIS_V6.go("global")')
 global_text=pg.locator('.main').inner_text()
 for label, table, field, filter_value, target in [
  ('Recorded occupied without active Contract','facList','contract','MISSING','facilities'),
  ('Import records blocked / needing review','importList','stage','NEEDS_REVIEW','imports')]:
  q=pg.locator('.mini-stat').filter(has=pg.locator('span',has_text=label))
  # pick the matching mini-stat with desired label
  btt=pg.locator(f'[data-page="{target}"][data-preset="{table}|{field}|{filter_value}"]').first
  cnt=int(re.search(r'\d+',btt.inner_text()).group())
  btt.click()
  matching=pg.evaluate('(id)=>window.MMIS_V6.tableResults(id).length',table)
  record('global-exception-'+table,f'{cnt} source records on click',matching,cnt==matching,'P0' if cnt!=matching else 'informational')
  pg.evaluate('()=>window.MMIS_V6.go("global")')
 # overdue global KPI links to general Vendor list without overdue filter
 pg.evaluate('()=>window.MMIS_V6.go("global")')
 pg.locator('.metric-card').filter(has_text='Overdue invoice balance').first.click()
 target=pg.evaluate('window.MMIS_V6.state.page')
 linked=pg.evaluate('window.MMIS_V6.tableResults("vendorList").length') if target=='vendors' else -1
 allv=len(pg.evaluate('window.MMIS_V6.data.vendors'))
 record('global-overdue-drilldown','Only Vendors/invoices contributing to overdue balance',{'destination':target,'matching_vendor_rows':linked,'all_vendors':allv,'active_vendor_filter':pg.evaluate('window.MMIS_V6.state.filters.vendorList||{}')},False,'P0')
 pg.evaluate('()=>window.MMIS_V6.go("global")')
 # source-level 61-90 cohort cross drilling
 d=pg.evaluate('window.MMIS_V6.data')
 by_fac={f['id']:f for f in d['facilities']}; inv=d['invoices']
 exact={i['vendorId'] for i in inv if i['unpaid']>0 and 61<=i['daysOverdue']<=90}
 filtered_shop={i['vendorId'] for i in inv if i['unpaid']>0 and 61<=i['daysOverdue']<=90 and by_fac[i['facilityId']]['type']=='SHOP'}
 maxdays={}
 for i in inv:
  if i['unpaid']>0:maxdays[i['vendorId']]=max(maxdays.get(i['vendorId'],0),i['daysOverdue'])
 old={v for v,d in maxdays.items() if 61<=d<=90}
 record('vendor-aging-population','Any invoice with 61–90-day unpaid balance, distinct Vendor grain',{'expected':len(exact),'current_max_age':len(old),'excluded_ids':sorted(exact-old)},exact==old,'P0')
 record('shop-cross-domain-61-90','Shop-specific invoice-verified Vendor cohort',{'shop_count':len(filtered_shop),'current_vendor_filter_all_types':len(old),'false_positive':sorted(old-filtered_shop)},filtered_shop==old,'P0')
 # service due dates and evidence for SLAs
 due_present=sum('dueAt' in x for x in d['requests'])
 record('request-sla-due-evidence','Case dueAt timestamp and source SLA/owner evidence',{'cases':len(d['requests']),'dueAt_available':due_present,'usesAgeDaysOnly':True},due_present==len(d['requests']),'P1')
 # role-specific: pending Vendor authenticated finder and application CTA must create application or open form, it does not
 pg.locator('#role-select').select_option('vendor-pending')
 record('pending-vendor-no-operational-menus','Only My Workspace and Public Shop Finder',pg.locator('.nav-item').all_text_contents(),pg.locator('.nav-item').count()==2)
 pg.locator('.nav-item[data-page="shop-finder"]').click()
 auth_header=pg.locator('.public-header').inner_text()
 record('public-header-auth-persistence','Signed-in header contains own identity and Logout, no Sign In',auth_header,('Grace Akello' in auth_header and 'Log out' in auth_header and 'Sign in' not in auth_header))
 pg.locator('.shop-card button[data-kind="listing"]').first.click()
 has_drawer=pg.locator('.drawer').count()>0
 action_label=pg.locator('.drawer [data-act="source-demo"]').inner_text() if has_drawer else ''
 record('shop-rental-application','Application data entry and trackable request created',{'drawer_open':has_drawer,'source_action':action_label,'form_fields':pg.locator('.drawer input, .drawer textarea').count()},False,'P0')
 pg.keyboard.press('Escape')
 # a clicked listing is not retained when the simulated user enters auth
 pg.keyboard.press('Escape')
 pg.locator('#role-select').select_option('public')
 pg.evaluate('()=>window.MMIS_V6.go("shop-finder")')
 pg.locator('.shop-card button[data-kind="listing"]').first.click()
 first_listing=pg.evaluate('window.MMIS_V6.state.drawer.id')
 pg.keyboard.press('Escape')
 pg.locator('.public-header [data-act="simulate-login"]').click()
 after_login={'page':pg.evaluate('window.MMIS_V6.state.page'),'hash':pg.evaluate('location.hash'),'listingSelected':pg.evaluate('window.MMIS_V6.state.drawer?.id||null')}
 record('return-to-selected-listing','After guest signs in preserve selected Shop listing/application return target',{'selected':first_listing,'afterLogin':after_login},after_login['listingSelected']==first_listing,'P0')
 pg.locator('#role-select').select_option('super')
 # staff and RBAC: static capability matrix only
 pg.locator('#role-select').select_option('super')
 pg.evaluate('()=>window.MMIS_V6.go("roles")')
 record('rbac-effective-policy','Per-account effective permissions, explicit deny, audit history, target authorization',{'capability_matrix_rows':pg.locator('table.permissions tbody tr').count(),'per_user_grants_table':pg.locator('table[data-grants]').count(),'permission_change_controls':pg.locator('[data-act="grant"],[data-act="revoke"]').count()},False,'P1')
 # rental readiness: UI select and fake preview, not real per-vendor preview
 pg.evaluate('()=>window.MMIS_V6.go("rental")')
 checkboxes=pg.locator('input[data-select]').count()
 pg.locator('input[data-select]').first.check()
 pg.locator('[data-act="preview-selected"]').first.click()
 txt=pg.locator('.drawer').inner_text()
 record('rental-preview-posting-gate','No posting allowed while Finance policy HOLD',{'selected_rows':checkboxes,'contains_NEVER_POST': 'NEVER POST' in txt,'POST_ctls':pg.locator('[data-act="generate-invoice"],[data-act="post-invoice"]').count()},'NEVER POST' in txt and pg.locator('[data-act="generate-invoice"],[data-act="post-invoice"]').count()==0)
 record('rental-full-readiness-journey','Actual Vendor/Contract terms version, first liability date, period collision, reviewer acceptance and recovery evidence',{'preview_contains_date': 'First liability' in txt,'contains_policy_version':'Policy version' in txt,'contains_existing_invoice':'Existing invoice' in txt},False,'P0')
 pg.keyboard.press('Escape')
 # Supplier PO navigation (read-only link)
 pg.evaluate('()=>window.MMIS_V6.go("suppliers")')
 pg.locator('[data-kind="po"]').first.click()
 po_text=pg.locator('.drawer').inner_text()
 record('supplier-po-evidence','PO drawer shows linked Gate token and status',{'has_source_po':'Source' in po_text or 'PO' in po_text,'has_gate':'Gate token' in po_text},'Gate token' in po_text)
 record('supplier-award-to-settlement','Transactional Vendor award > PO issue > Supplier ACK > Goods receipt > payable settlement journey',{'drawer_only':True,'transition_actions':pg.locator('.drawer button[data-act="status-next"]').count()},False,'P1')
 pg.keyboard.press('Escape')
 # browser back cross route
 pg.evaluate('()=>window.MMIS_V6.go("global")');pg.evaluate('()=>window.MMIS_V6.go("vendors")')
 before=pg.locator('h1.page-title').inner_text()
 pg.go_back(wait_until='domcontentloaded');pg.wait_for_timeout(80)
 after=pg.locator('h1.page-title').inner_text()
 record('browser-history-navigation','Back returns to Global Operations after Vendor Overview',{'before':before,'after':after,'hash':pg.evaluate('location.hash')},'Global Operations' in after,'P1')
 # catalog descriptors are proposed not full source contract
 c=d['catalog'];required=['grain','timeBasis','eligibleStatuses','filtersApplied','currencyCode','evidenceSource','dataQuality'];missing={k:sum(k not in x for x in c) for k in required}
 record('catalog-production-readiness','179 groups with production KPI source/grain/time-basis/eligibility metadata',{'count':len(c),'missingFields':missing},not any(missing.values()),'P1')
 b.close()
path=Path(__file__).resolve().parent / 'INDEPENDENT_TESTS.json'
path.write_text(json.dumps(report,indent=2,ensure_ascii=False))
print(json.dumps({'observations':len(report['observations']),'failed':sum(not x['pass'] for x in report['observations']),'errors':report['pageErrors'],'results':report['observations']},indent=2,ensure_ascii=False))
