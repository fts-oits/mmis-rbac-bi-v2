from playwright.sync_api import sync_playwright
from pathlib import Path
import os
base=Path(__file__).resolve().parent
html=(base/'input_demo/index.html').read_text()
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path=os.environ.get('MMIS_CHROMIUM_PATH') or None,args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1440,'height':960})
 page.set_content(html,wait_until='domcontentloaded')
 page.locator('[data-page="facilities"][data-preset="facList|contract|MISSING"]').first.click()
 page.screenshot(path=str(base/'01_13_Facility_gap_count_opens_7_filtered_units.png'),full_page=False)
 page.evaluate('()=>window.MMIS_V6.go("global")')
 page.locator('[data-page="imports"][data-preset="importList|stage|NEEDS_REVIEW"]').first.click()
 page.screenshot(path=str(base/'02_12_Import_exception_count_opens_6_filtered_rows.png'),full_page=False)
 page.locator('#role-select').select_option('vendor-pending')
 page.locator('[data-page="shop-finder"]').first.click()
 page.locator('.shop-card button[data-kind="listing"]').first.click()
 page.screenshot(path=str(base/'03_Apply_button_opens_readonly_information_drawer.png'),full_page=False)
 b.close()
print('captured 3')
