# MMIS V6 — PM Demo QA Report

**QA date:** 10 November 2026 · Offline Chromium / Python Playwright · Fully inlined HTML source

| Test family | Actual result |
|---|---|
| Browser navigation | 16 named pages successfully rendered |
| Persona previews | SuperAdmin, MarketMaster, read-only, pending/active Vendor, pending/active Supplier, Gate Staff, Stock Counter, public Guest |
| Screenshots | 45 desktop/mobile/evidence-drawer captures |
| Responsive no-overflow | 16 pages × 8 viewport widths = 128 checks, all passed |
| Behavior and consistency | 25 additional checks passed |
| **Total matrix checks** | **153 / 153 PASS** |
| Request Center | 55 unique open cases = eight exclusive category subtotal |
| Exact filtered export | Rental case filter 9 rows = CSV 9 rows |
| Market scope | Current Market selection yields exactly matching source cases |
| Facility Contract gaps | KPI 13 = 13 filtered detail rows |
| Rental preflight | Local multi-select opens READ-ONLY / NEVER POST details |
| KPI library | 179 total families; Vendor filtered 45 |
| Role restrictions | Pending Vendor, pending Supplier, Gate Staff, Stock Counter and public Guest navigation passes |
| Public/authenticated Shop Finder | Signed-in pending Vendor header contains account and Logout, no Sign In |
| PM feedback | Local JSON export captures checked decisions |
| Remote asset dependencies | None |

These are **demo QA tests**; they do not certify production RBAC, financial correctness, native PostgreSQL or live UI/API integrations. See `qa/BROWSER_QA_MATRIX.json` for the machine-readable evidence.
