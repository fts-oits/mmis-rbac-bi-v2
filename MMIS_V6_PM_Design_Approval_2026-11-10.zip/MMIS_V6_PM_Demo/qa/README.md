# Browser QA Evidence

`BROWSER_QA_MATRIX.json` records the actual Chromium/Playwright outcome from the self-contained `index.html` source.

Execution on 10 November 2026:

- 16 named page routes (plus additional role-specific workspace perspectives) exercised on 8 widths: 320, 375, 390, 768, 1024, 1280, 1440 and 1920px.
- 128 no-overflow checks plus 25 behavioral checks = **153 / 153 PASS**.
- 55 global unique open cases match the sum of eight case categories.
- Rental category filter yields 9 records and exports 9 matching CSV rows; Market labels exported in user-visible form.
- Market scope, Facility contract-gap counts, selection-only rental preflight, entire 179 KPI families, pending-role navigation, authenticated public header, local PM feedback and no external runtime resources verified.
- No JavaScript page errors in the smoke run.

**Not tested:** live MMIS authorization, authenticated frontend/API/PostgreSQL/SMTP, accounting certification, backend security, exact-feature-branch builds, payment/URA/EFRIS, PDF rendering, native iOS/Android devices or deployment runners.

To reproduce, install Python `playwright` and locally available Chromium; run the two test scripts against an extracted prototype. The scripts are optional and not loaded by the demo itself.
